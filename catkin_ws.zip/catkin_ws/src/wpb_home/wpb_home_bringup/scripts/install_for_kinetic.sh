#!/bin/bash
sudo apt-get install ros-kinetic-joint-state-publisher-gui
sudo apt-get install ros-kinetic-joy
sudo apt-get install ros-kinetic-hector-mapping
sudo apt-get install ros-kinetic-gmapping
sudo apt-get install ros-kinetic-navigation
sudo apt-get install ros-kinetic-cv-bridge
sudo apt-get install ros-kinetic-audio-common
sudo apt-get install ros-kinetic-controller-manager