#!/bin/bash
sudo apt-get update
sudo apt-get install ros-melodic-map-server
sudo apt-get install ros-melodic-navigation