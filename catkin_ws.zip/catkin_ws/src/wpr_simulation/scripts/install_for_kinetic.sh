#!/bin/bash
sudo apt-get install -y ros-kinetic-desktop-full
sudo apt-get install -y ros-kinetic-navigation
sudo apt-get install -y ros-kinetic-joy
sudo apt-get install -y ros-kinetic-gazebo-ros-control
sudo apt-get install -y ros-kinetic-joint-state-controller
sudo apt-get install -y ros-kinetic-position-controllers
sudo apt-get install -y ros-kinetic-effort-controllers
sudo apt-get install -y ros-kinetic-cv-bridge
sudo apt-get install -y ros-kinetic-controller-manager
sudo apt-get install -y ros-kinetic-hector-mapping
sudo apt-get install -y ros-kinetic-gmapping